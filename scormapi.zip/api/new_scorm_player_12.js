(function () {
  var _DEBUG = true; //my debug logic
  var my_get_data = new Object();
  var my_get_value = "";
  var mydata = new Object();
  var my_score = 0;
  var my_end_active = false;

  window.simplifyScorm.ScormAPI = ScormAPI;

  var BaseAPI = window.simplifyScorm.BaseAPI;
  var constants = window.simplifyScorm.constants;
  var jsonFormatter = window.simplifyScorm.jsonFormatter;

  window.API = new ScormAPI();

  if (_DEBUG) window.API.apiLogLevel = 1;
  // Log everything (Debug)
  else window.API.apiLogLevel = 5; // No logging

  var ibm_token = $("#ibm_token").val();
  if (_DEBUG) console.log("Ibm Token: ", ibm_token);

  $.ajaxSetup({
    headers: {
      "X-CSRF-TOKEN": ibm_token,
    },
  });

  if (_DEBUG) console.log("Version: ", $version);

  var get_url = "";
  if ($method == "dispatch")
    get_url =
      $base_url +
      "/dispatch/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $destination +
      "/" +
      $dispatch +
      "/" +
      $version +
      "/" +
      $attempt +
      "/getSCORM";
  else if ($method == "invite")
    get_url =
      $base_url +
      "/invite/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $invitation +
      "/" +
      $version +
      "/" +
      $attempt +
      "/getSCORM";
  else if ($method == "normal")
    get_url =
      $base_url +
      "/elearning/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $version +
      "/" +
      $attempt +
      "/getSCORM";
  else if ($method == "api_normal") {
    get_url =
      $base_url +
      "/api/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $learner +
      "/" +
      $version +
      "/" +
      $attempt +
      "/get";
  }

  if (_DEBUG) console.log("First Get Url: ", get_url);

  $.getJSON(get_url, function () {})
    .done(function (my_data) {
      my_get_data = my_data;
      if (_DEBUG) console.log("My First Get Data: ", my_get_data);
    })
    .fail(function (error) {
      console.log("Error To Get First Data", error);
    });

  var my_timerVar = setInterval(my_countTimer, 1000);

  var my_totalSeconds = 0;

  function my_countTimer() {
    ++my_totalSeconds;
    var hour = Math.floor(my_totalSeconds / 3600);
    var minute = Math.floor((my_totalSeconds - hour * 3600) / 60);
    var seconds = my_totalSeconds - (hour * 3600 + minute * 60);
    if (hour < 10) hour = "0" + hour;
    if (minute < 10) minute = "0" + minute;
    if (seconds < 10) seconds = "0" + seconds;

    $("#scorm_timer").val(hour + ":" + minute + ":" + seconds);
  }

  if ($method == "dispatch")
    put_url =
      $base_url +
      "/dispatch/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $destination +
      "/" +
      $dispatch +
      "/" +
      $version +
      "/" +
      $attempt +
      "/putSCORM";
  else if ($method == "invite")
    put_url =
      $base_url +
      "/invite/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $invitation +
      "/" +
      $version +
      "/" +
      $attempt +
      "/putSCORM";
  else if ($method == "normal")
    put_url =
      $base_url +
      "/elearning/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $version +
      "/" +
      $attempt +
      "/putSCORM";
  else if ($method == "api_normal") {
    put_url =
      $base_url +
      "/api/json/" +
      $course +
      "/" +
      $scorm +
      "/" +
      $sco +
      "/" +
      $user +
      "/" +
      $learner +
      "/" +
      $version +
      "/" +
      $attempt +
      "/put";
  }

  function ScormAPI() {
    var _self = this;
    BaseAPI.call(_self);

    // API Signature
    _self.LMSInitialize = LMSInitialize;
    _self.LMSFinish = LMSFinish;
    _self.LMSGetValue = LMSGetValue;
    _self.LMSSetValue = LMSSetValue;
    _self.LMSCommit = LMSCommit;
    _self.LMSGetLastError = LMSGetLastError;
    _self.LMSGetErrorString = LMSGetErrorString;
    _self.LMSGetDiagnostic = LMSGetDiagnostic;

    // Data Model
    _self.cmi = new CMI(_self);

    // Utility Functions
    _self.checkState = checkState;
    _self.getLmsErrorMessageDetails = getLmsErrorMessageDetails;
    _self.loadFromJSON = loadFromJSON;
    _self.reset = reset;

    function LMSInitialize() {
      var returnValue = constants.SCORM_FALSE;

      if (_self.isInitialized()) {
        _self.throwSCORMError(101, "LMS was already initialized!");
      } else if (_self.isTerminated()) {
        _self.throwSCORMError(101, "LMS is already finished!");
      } else {
        _self.currentState = constants.STATE_INITIALIZED;
        returnValue = constants.SCORM_TRUE;
        _self.processListeners("LMSInitialize");
      }

      _self.apiLog(
        "LMSInitialize",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );
      _self.clearSCORMError(returnValue);

      return returnValue;
    }

    function LMSFinish() {
      var returnValue = constants.SCORM_FALSE;

      if (_self.checkState()) {
        _self.currentState = constants.STATE_TERMINATED;
        returnValue = constants.SCORM_TRUE;
        _self.processListeners("LMSFinish");
      }

      _self.apiLog(
        "LMSFinish",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );
      _self.clearSCORMError(returnValue);

      return returnValue;
    }

    function LMSGetValue(CMIElement) {
      var returnValue = "";

      if (_self.checkState()) {
        returnValue = getCMIValue(CMIElement);
        _self.processListeners("LMSGetValue", CMIElement);
      }

      _self.apiLog(
        "LMSGetValue",
        CMIElement,
        ": returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );
      _self.clearSCORMError(returnValue);

      return returnValue;
    }

    function LMSSetValue(CMIElement, value) {
      mydata.my_vtt_y = $my_vtt_y;

      if (_DEBUG) console.log("CMIElement: ", CMIElement);
      if (_DEBUG) console.log("Value: ", value);

      switch (CMIElement) {
        case "cmi.core.lesson_mode":
          mydata.cmi__core__lesson_mode = value;
          break;
        case "cmi.core.lesson_status":
          if ($my_vtt_y == 1 && value == "incomplete") {
            value = "passed";
            console.log("my lesson status => ", value);
            if ($method == "dispatch") {
              var my_time = $("#scorm_timer").val();
              DispatchDriver.SetSummary(
                "completed",
                "passed",
                my_score,
                my_time
              );
              DispatchDriver.CommitData();
            }
          }
          mydata.cmi__core__lesson_status = value;
          break;
        case "cmi.success_status":
          mydata.cmi__success_status = value;
          break;
        case "cmi.core.exit":
          mydata.cmi__core__exit = value;
          break;
        case "cmi.core.lesson_location":
          mydata.cmi__core__lesson_location = value;
          break;
        case "cmi.core.total_time":
          mydata.cmi__core__total_time = value;
          break;
        case "cmi.suspend_data":
          mydata.cmi__suspend_data = value;
          break;
        case "cmi.core.score.raw":
          mydata.cmi__core__score__raw = value;
          my_score = value;
          break;
        case "cmi.core.score.max":
          mydata.cmi__core__score__max = value;
          break;
        case "cmi.core.score.min":
          mydata.cmi__core__score__min = value;
          break;
        case "cmi.comments":
          mydata.cmi__comments = value;
          break;
        case "cmi.core.comments":
          mydata.cmi__core__comments = value;
          break;
        case "cmi.core.student_name":
          mydata.cmi__core__student_name = value;
          break;
        case "cmi.core.student_id":
          mydata.cmi__core__student_id = value;
          break;
        case "cmi.core.session_time":
          mydata.cmi__core__session_time = value;
          break;

        case "cmi.objectives..status":
          mydata.cmi__core__lesson_status = value;
          break;
        case "cmi.objectives..score.raw":
          mydata.cmi__core__score__raw = value;
          my_score = value;
          break;
        case "cmi.objectives..score.max":
          mydata.cmi__core__score__max = value;
          break;
        case "cmi.objectives..score.min":
          mydata.cmi__core__score__min = value;
          break;

        case "cmi.interactions..result":
          my_end_active = true;
          break;
      }

      if ($method == "dispatch") {
        DispatchDriver.SCORM_SetValue(CMIElement, value);
      }

      if ($my_vtt_y == 1) {
        mydata.cmi__core__total_time = $("#scorm_timer").val();

        if (_DEBUG) console.log("Submitted_Data", mydata);
        if (_DEBUG) console.log("My Url: ", put_url);

        $.ajax({
          url: put_url,
          type: "post",
          dataType: "json",
          async: true,
          data: mydata,
          success: function (result) {
            if (_DEBUG) console.log("Tracking Data", result);
            //console.log('my_end_active', my_end_active);
            if (my_end_active) {
              my_window.close();
            }
          },
          error: function (error) {
            if (_DEBUG) console.log("Error From DB", error);
          },
        });
      }

      var returnValue = "";

      if (_self.checkState()) {
        returnValue = setCMIValue(CMIElement, value);
        _self.processListeners("LMSSetValue", CMIElement, value);
      }

      _self.apiLog(
        "LMSSetValue",
        CMIElement,
        ": " + value + ": returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );
      _self.clearSCORMError(returnValue);

      return returnValue;
    }

    function LMSCommit() {
      mydata.cmi__core__total_time = $("#scorm_timer").val();

      if (_DEBUG) console.log("Final Submitted_Data", mydata);
      if (_DEBUG) console.log("Final My Url: ", put_url);

      $.ajax({
        url: put_url,
        type: "post",
        dataType: "json",
        async: true,
        data: mydata,
        success: function (result) {
          if (_DEBUG) console.log("Final Tracking Data", result);
        },
        error: function (error) {
          if (_DEBUG) console.log("Error From DB", error);
        },
      });

      clearInterval(my_timerVar);

      var returnValue = constants.SCORM_FALSE;

      if (_self.checkState()) {
        returnValue = constants.SCORM_TRUE;
        _self.processListeners("LMSCommit");
      }

      _self.apiLog(
        "LMSCommit",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );
      _self.clearSCORMError(returnValue);

      return returnValue;
    }

    function LMSGetLastError() {
      var returnValue = _self.lastErrorCode;

      _self.processListeners("LMSGetLastError");

      _self.apiLog(
        "LMSGetLastError",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );

      return returnValue;
    }

    function LMSGetErrorString(CMIErrorCode) {
      var returnValue = "";

      if (CMIErrorCode !== null && CMIErrorCode !== "") {
        returnValue = _self.getLmsErrorMessageDetails(CMIErrorCode);
        _self.processListeners("LMSGetErrorString");
      }

      _self.apiLog(
        "LMSGetErrorString",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );

      return returnValue;
    }

    function LMSGetDiagnostic(CMIErrorCode) {
      var returnValue = "";

      if (CMIErrorCode !== null && CMIErrorCode !== "") {
        returnValue = _self.getLmsErrorMessageDetails(CMIErrorCode, true);
        _self.processListeners("LMSGetDiagnostic");
      }

      _self.apiLog(
        "LMSGetDiagnostic",
        null,
        "returned: " + returnValue,
        constants.LOG_LEVEL_INFO
      );

      return returnValue;
    }

    function checkState() {
      if (!this.isInitialized()) {
        this.throwSCORMError(301);
        return false;
      }

      return true;
    }

    function setCMIValue(CMIElement, value) {
      if (!CMIElement || CMIElement === "") {
        return constants.SCORM_FALSE;
      }

      var structure = CMIElement.split(".");
      var refObject = _self;
      var found = constants.SCORM_FALSE;

      for (var i = 0; i < structure.length; i++) {
        if (i === structure.length - 1) {
          if (!refObject.hasOwnProperty(structure[i])) {
            if (_DEBUG)
              _self.throwSCORMError(
                101,
                "setCMIValue did not find an element for: " + CMIElement
              );
          } else {
            refObject[structure[i]] = value;
            found = constants.SCORM_TRUE;
          }
        } else {
          refObject = refObject[structure[i]];
          if (!refObject) {
            if (_DEBUG)
              _self.throwSCORMError(
                101,
                "setCMIValue did not find an element for: " + CMIElement
              );
            break;
          }

          if (refObject.hasOwnProperty("childArray")) {
            var index = parseInt(structure[i + 1], 10);

            // SCO is trying to set an item on an array
            if (!isNaN(index)) {
              var item = refObject.childArray[index];

              if (item) {
                refObject = item;
              } else {
                var newChild;

                if (CMIElement.indexOf("cmi.objectives") > -1) {
                  newChild = new CMI_ObjectivesObject(_self);
                } else if (CMIElement.indexOf(".correct_responses") > -1) {
                  newChild = new CMI_InteractionsCorrectResponsesObject(_self);
                } else if (CMIElement.indexOf(".objectives") > -1) {
                  newChild = new CMI_InteractionsObjectivesObject(_self);
                } else if (CMIElement.indexOf("cmi.interactions") > -1) {
                  newChild = new CMI_InteractionsObject(_self);
                }

                if (!newChild) {
                  if (_DEBUG)
                    _self.throwSCORMError(
                      101,
                      "Cannot create new sub entity: " + CMIElement
                    );
                } else {
                  refObject.childArray.push(newChild);
                  refObject = newChild;
                }
              }

              // Have to update i value to skip the array position
              i++;
            }
          }
        }
      }

      if (found === constants.SCORM_FALSE) {
        _self.apiLog(
          "LMSSetValue",
          null,
          "There was an error setting the value for: " +
            CMIElement +
            ", value of: " +
            value,
          constants.LOG_LEVEL_WARNING
        );
      }

      return found;
    }

    function getCMIValue(CMIElement) {
      if (_DEBUG) console.log("Get CMIElement: ", CMIElement);

      if (!CMIElement || CMIElement === "") {
        return "";
      }

      if (Object.keys(my_get_data).length == 0) {
        if (_DEBUG) console.log("Get Url: ", get_url);

        $.getJSON(get_url, function (my_data) {
          var my_val = "";

          switch (CMIElement) {
            case "cmi.core.lesson_mode":
              my_val = my_data.cmi_core_lesson_mode;
              break;
            case "cmi.core.lesson_status":
              my_val = my_data.cmi_core_lesson_status;
              break;
            case "cmi.success_status":
              my_val = mydata.cmi_success_status;
              break;
            case "cmi.core.exit":
              my_val = my_data.cmi_core_exit;
              break;
            case "cmi.core.lesson_location":
              my_val = my_get_data.cmi_core_lesson_location;
              break;
            case "cmi.suspend_data":
              my_val = my_data.cmi_suspend_data;
              break;
            case "cmi.interactions.0.time":
              my_val = my_data.cmi_core_total_time;
              break;
            case "cmi.core.total_time":
              my_val = my_data.cmi_core_total_time;
              break;
            case "cmi.core.score.raw":
              my_val = my_data.cmi_core_score_raw;
              break;
            case "cmi.core.score.max":
              my_val = my_data.cmi_core_score_max;
              break;
            case "cmi.core.score.min":
              my_val = my_data.cmi_core_score_min;
              break;
            case "cmi.core.lesson_status":
              my_val = my_data.cmi_core_lesson_status;
              break;
            case "cmi.comments":
              my_val = mydata.cmi_comments;
              break;
            case "cmi.core.comments":
              my_val = mydata.cmi_core_comments;
              break;
            case "cmi.core.student_name":
              my_val = mydata.cmi_core_student_name;
              break;
            case "cmi.core.student_id":
              my_val = mydata.cmi_core_student_id;
              break;

            case "cmi.objectives..status":
              my_val = my_data.cmi_core_lesson_status;
              break;
            case "cmi.objectives..score.raw":
              my_val = my_data.cmi_core_score_raw;
              break;
            case "cmi.objectives..score.max":
              my_val = my_data.cmi_core_score_max;
              break;
            case "cmi.objectives..score.min":
              my_val = my_data.cmi_core_score_min;
              break;
          }
          my_get_value = my_val;
          my_get_data = my_data;
          if (_DEBUG) console.log("My Get Value: ", my_val);
        });

        if (CMIElement == "cmi.core.lesson_mode") {
          if (
            typeof my_get_data.cmi_core_lesson_mode == "undefined" ||
            my_get_data.cmi_core_lesson_mode == null ||
            my_get_data.cmi_core_lesson_mode === "incomplete" ||
            !my_get_data.cmi_core_lesson_mode
          ) {
            my_get_value = "normal";
          }
        } else if (CMIElement == "cmi.core.lesson_status") {
          if (
            typeof my_get_data.cmi_core_lesson_status == "undefined" ||
            my_get_data.cmi_core_lesson_status == null ||
            my_get_data.cmi_core_lesson_status === "incomplete" ||
            !my_get_data.cmi_core_lesson_status
          ) {
            my_get_value = "unknown";
          }
        } else if (CMIElement == "cmi.core.lesson_location") {
          if (
            typeof my_get_data.cmi_core_lesson_location == "undefined" ||
            my_get_data.cmi_core_lesson_location == null ||
            my_get_data.cmi_core_lesson_location === "incomplete" ||
            !my_get_data.cmi_core_lesson_location
          ) {
            my_get_value = "index.html";
          }
        } else if (CMIElement == "cmi.suspend_data") {
          if (
            typeof my_get_data.cmi_suspend_data == "undefined" ||
            my_get_data.cmi_suspend_data == null ||
            !my_get_data.cmi_suspend_data
          ) {
            my_get_value = "";
          }
        } else if (CMIElement == "cmi.core.student_name") {
          if (
            typeof my_get_data.cmi_core_student_name == "undefined" ||
            my_get_data.cmi_core_student_name == null ||
            !my_get_data.cmi_core_student_name
          ) {
            my_get_value = "";
          }
        } else if (CMIElement == "cmi.core.student_id") {
          if (
            typeof my_get_data.cmi_core_student_name == "undefined" ||
            my_get_data.cmi_core_student_id == null ||
            !my_get_data.cmi_core_student_id
          ) {
            my_get_value = "";
          }
        } else if (CMIElement == "cmi.comments") {
          if (
            typeof my_get_data.cmi_comments == "undefined" ||
            my_get_data.cmi_comments == null ||
            !my_get_data.cmi_comments
          ) {
            my_get_value = "";
          }
        }

        return my_get_value;
      }

      if (_DEBUG) console.log("My Get Data: ", my_get_data);

      if (Object.keys(my_get_data).length != 0) {
        if (_DEBUG)
          console.log(
            "My Get Location: ",
            my_get_data.cmi_core_lesson_location
          );

        switch (CMIElement) {
          case "cmi.core.lesson_mode":
            return my_get_data.cmi_core_lesson_mode;
          case "cmi.success_status":
            return my_get_data.cmi_success_status;
          case "cmi.core.exit":
            return my_get_data.cmi_core_exit;
          case "cmi.core.lesson_location":
            return my_get_data.cmi_core_lesson_location;
          case "cmi.suspend_data":
            return my_get_data.cmi_suspend_data;
          case "cmi.interactions.0.time":
            return my_get_data.cmi_core_total_time;
          case "cmi.core.total_time":
            return my_get_data.cmi_core_total_time;
          case "cmi.core.score.raw":
            return my_get_data.cmi_core_score_raw;
          case "cmi.core.score.max":
            return my_get_data.cmi_core_score_max;
          case "cmi.core.score.min":
            return my_get_data.cmi_core_score_min;
          case "cmi.core.lesson_status":
            return my_get_data.cmi_core_lesson_status;
          case "cmi.comments":
            return my_get_data.cmi_comments;
          case "cmi.core.comments":
            return my_get_data.cmi_core_comments;
          case "cmi.core.student_name":
            return my_get_data.cmi_core_student_name;
          case "cmi.core.student_id":
            return my_get_data.cmi_core_student_id;

          case "cmi.objectives..score.raw":
            return my_get_data.cmi_core_score_raw;
          case "cmi.objectives..score.max":
            return my_get_data.cmi_core_score_max;
          case "cmi.objectives..score.min":
            return my_get_data.cmi_core_score_min;
          case "cmi.objectives..status":
            return my_get_data.cmi_core_lesson_status;
          default:
            return "";
        }
      } else {
        var structure = CMIElement.split(".");
        var refObject = _self;
        var lastProperty = null;

        for (var i = 0; i < structure.length; i++) {
          lastProperty = structure[i];

          if (i === structure.length - 1) {
            if (!refObject.hasOwnProperty(structure[i])) {
              _self.throwSCORMError(
                101,
                "getCMIValue did not find a value for: " + CMIElement
              );
            }
          }

          refObject = refObject[structure[i]];
        }

        if (refObject === null || refObject === undefined) {
          if (lastProperty === "_children") {
            _self.throwSCORMError(202);
          } else if (lastProperty === "_count") {
            _self.throwSCORMError(203);
          }
          return "";
        } else {
          return refObject;
        }
      }
    }

    function getLmsErrorMessageDetails(errorNumber, detail) {
      var basicMessage = "";
      var detailMessage = "";

      // Set error number to string since inconsistent from modules if string or number
      errorNumber = String(errorNumber);

      switch (errorNumber) {
        case "101":
          basicMessage = "General Exception";
          detailMessage =
            "No specific error code exists to describe the error. Use LMSGetDiagnostic for more information";
          break;

        case "201":
          basicMessage = "Invalid argument error";
          detailMessage =
            "Indicates that an argument represents an invalid data model element or is otherwise incorrect.";
          break;

        case "202":
          basicMessage = "Element cannot have children";
          detailMessage =
            'Indicates that LMSGetValue was called with a data model element name that ends in "_children" for a data model element that does not support the "_children" suffix.';
          break;

        case "203":
          basicMessage = "Element not an array - cannot have count";
          detailMessage =
            'Indicates that LMSGetValue was called with a data model element name that ends in "_count" for a data model element that does not support the "_count" suffix.';
          break;

        case "301":
          basicMessage = "Not initialized";
          detailMessage =
            "Indicates that an API call was made before the call to LMSInitialize.";
          break;

        case "401":
          basicMessage = "Not implemented error";
          detailMessage =
            "The data model element indicated in a call to LMSGetValue or LMSSetValue is valid, but was not implemented by this LMS. SCORM 1.2 defines a set of data model elements as being optional for an LMS to implement.";
          break;

        case "402":
          basicMessage = "Invalid set value, element is a keyword";
          detailMessage =
            'Indicates that LMSSetValue was called on a data model element that represents a keyword (elements that end in "_children" and "_count").';
          break;

        case "403":
          basicMessage = "Element is read only";
          detailMessage =
            "LMSSetValue was called with a data model element that can only be read.";
          break;

        case "404":
          basicMessage = "Element is write only";
          detailMessage =
            "LMSGetValue was called on a data model element that can only be written to.";
          break;

        case "405":
          basicMessage = "Incorrect Data Type";
          detailMessage =
            "LMSSetValue was called with a value that is not consistent with the data format of the supplied data model element.";
          break;

        default:
          basicMessage = "No Error";
          detailMessage = "No Error";
          break;
      }

      return detail ? detailMessage : basicMessage;
    }

    function loadFromJSON(json, CMIElement) {
      if (!_self.isNotInitialized()) {
        console.error(
          "loadFromJSON can only be called before the call to LMSInitialize."
        );
        return;
      }

      CMIElement = CMIElement || "cmi";

      for (var key in json) {
        if (json.hasOwnProperty(key) && json[key]) {
          var currentCMIElement = CMIElement + "." + key;
          var value = json[key];

          if (value["childArray"]) {
            for (var i = 0; i < value["childArray"].length; i++) {
              _self.loadFromJSON(
                value["childArray"][i],
                currentCMIElement + "." + i
              );
            }
          } else if (value.constructor === Object) {
            _self.loadFromJSON(value, currentCMIElement);
          } else {
            setCMIValue(currentCMIElement, value);
          }
        }
      }
    }

    function reset() {
      BaseAPI.reset.call(_self);

      // Data Model
      _self.cmi = new CMI(_self);
    }

    return _self;
  }

  function CMI(API) {
    return {
      _suspend_data: "",
      get suspend_data() {
        return this._suspend_data;
      },
      set suspend_data(suspend_data) {
        this._suspend_data = suspend_data;
      },

      _launch_data: "",
      get launch_data() {
        return this._launch_data;
      },
      set launch_data(launch_data) {
        API.isNotInitialized()
          ? (this._launch_data = launch_data)
          : API.throwSCORMError(403);
      },

      _comments: "",
      get comments() {
        return this._comments;
      },
      set comments(comments) {
        this._comments = comments;
      },

      _comments_from_lms: "",
      get comments_from_lms() {
        return this._comments_from_lms;
      },
      set comments_from_lms(comments_from_lms) {
        API.isNotInitialized()
          ? (this._comments_from_lms = comments_from_lms)
          : API.throwSCORMError(403);
      },

      core: {
        __children:
          "student_id,student_name,lesson_location,credit,lesson_status,entry,score,total_time,lesson_mode,exit,session_time",
        get _children() {
          return this.__children;
        },
        set _children(_children) {
          API.throwSCORMError(402);
        },

        _student_id: "",
        get student_id() {
          return this._student_id;
        },
        set student_id(student_id) {
          API.isNotInitialized()
            ? (this._student_id = student_id)
            : API.throwSCORMError(403);
        },

        _student_name: "",
        get student_name() {
          return this._student_name;
        },
        set student_name(student_name) {
          API.isNotInitialized()
            ? (this._student_name = student_name)
            : API.throwSCORMError(403);
        },

        _lesson_location: "",
        get lesson_location() {
          return this._lesson_location;
        },
        set lesson_location(lesson_location) {
          this._lesson_location = lesson_location;
        },

        _credit: "",
        get credit() {
          return this._credit;
        },
        set credit(credit) {
          API.isNotInitialized()
            ? (this._credit = credit)
            : API.throwSCORMError(403);
        },

        _lesson_status: "",
        get lesson_status() {
          return this._lesson_status;
        },
        set lesson_status(lesson_status) {
          this._lesson_status = lesson_status;
        },

        _entry: "",
        get entry() {
          return this._entry;
        },
        set entry(entry) {
          API.isNotInitialized()
            ? (this._entry = entry)
            : API.throwSCORMError(403);
        },

        _total_time: "",
        get total_time() {
          return this._total_time;
        },
        set total_time(total_time) {
          API.isNotInitialized()
            ? (this._total_time = total_time)
            : API.throwSCORMError(403);
        },

        _lesson_mode: "normal",
        get lesson_mode() {
          return this._lesson_mode;
        },
        set lesson_mode(lesson_mode) {
          API.isNotInitialized()
            ? (this._lesson_mode = lesson_mode)
            : API.throwSCORMError(403);
        },

        _exit: "",
        get exit() {
          return !this.jsonString ? API.throwSCORMError(404) : this._exit;
        },
        set exit(exit) {
          this._exit = exit;
        },

        _session_time: "",
        get session_time() {
          return !this.jsonString
            ? API.throwSCORMError(404)
            : this._session_time;
        },
        set session_time(session_time) {
          this._session_time = session_time;
        },

        score: {
          __children: "raw,min,max",
          get _children() {
            return this.__children;
          },
          set _children(_children) {
            API.throwSCORMError(402);
          },

          _raw: "",
          get raw() {
            return this._raw;
          },
          set raw(raw) {
            this._raw = raw;
          },

          _min: "",
          get min() {
            return this._min;
          },
          set min(min) {
            this._min = min;
          },

          _max: "100",
          get max() {
            return this._max;
          },
          set max(max) {
            this._max = max;
          },

          toJSON: jsonFormatter,
        },

        toJSON: jsonFormatter,
      },

      objectives: {
        __children: "id,score,status",
        get _children() {
          return this.__children;
        },
        set _children(_children) {
          API.throwSCORMError(402);
        },

        childArray: [],
        get _count() {
          return this.childArray.length;
        },
        set _count(_count) {
          API.throwSCORMError(402);
        },

        toJSON: jsonFormatter,
      },

      student_data: {
        __children: "mastery_score,max_time_allowed,time_limit_action",
        get _children() {
          return this.__children;
        },
        set _children(_children) {
          API.throwSCORMError(402);
        },

        _mastery_score: "",
        get mastery_score() {
          return this._mastery_score;
        },
        set mastery_score(mastery_score) {
          API.isNotInitialized()
            ? (this._mastery_score = mastery_score)
            : API.throwSCORMError(403);
        },

        _max_time_allowed: "",
        get max_time_allowed() {
          return this._max_time_allowed;
        },
        set max_time_allowed(max_time_allowed) {
          API.isNotInitialized()
            ? (this._max_time_allowed = max_time_allowed)
            : API.throwSCORMError(403);
        },

        _time_limit_action: "",
        get time_limit_action() {
          return this._time_limit_action;
        },
        set time_limit_action(time_limit_action) {
          API.isNotInitialized()
            ? (this._time_limit_action = time_limit_action)
            : API.throwSCORMError(403);
        },

        toJSON: jsonFormatter,
      },

      student_preference: {
        __children: "audio,language,speed,text",
        get _children() {
          return this.__children;
        },
        set _children(_children) {
          API.throwSCORMError(402);
        },

        _audio: "",
        get audio() {
          return this._audio;
        },
        set audio(audio) {
          this._audio = audio;
        },

        _language: "",
        get language() {
          return this._language;
        },
        set language(language) {
          this._language = language;
        },

        _speed: "",
        get speed() {
          return this._speed;
        },
        set speed(speed) {
          this._speed = speed;
        },

        _text: "",
        get text() {
          return this._text;
        },
        set text(text) {
          this._text = text;
        },

        toJSON: jsonFormatter,
      },

      interactions: {
        __children:
          "id,objectives,time,type,correct_responses,weighting,student_response,result,latency",
        get _children() {
          return this.__children;
        },
        set _children(_children) {
          API.throwSCORMError(402);
        },

        childArray: [],
        get _count() {
          return this.childArray.length;
        },
        set _count(_count) {
          API.throwSCORMError(402);
        },

        toJSON: jsonFormatter,
      },

      toJSON: jsonFormatter,
    };
  }

  function CMI_InteractionsObject(API) {
    return {
      _id: "",
      get id() {
        return !this.jsonString ? API.throwSCORMError(404) : this._id;
      },
      set id(id) {
        this._id = id;
      },

      _time: "",
      get time() {
        return !this.jsonString ? API.throwSCORMError(404) : this._time;
      },
      set time(time) {
        this._time = time;
      },

      _type: "",
      get type() {
        return !this.jsonString ? API.throwSCORMError(404) : this._type;
      },
      set type(type) {
        this._type = type;
      },

      _weighting: "",
      get weighting() {
        return !this.jsonString ? API.throwSCORMError(404) : this._weighting;
      },
      set weighting(weighting) {
        this._weighting = weighting;
      },

      _student_response: "",
      get student_response() {
        return !this.jsonString
          ? API.throwSCORMError(404)
          : this._student_response;
      },
      set student_response(student_response) {
        this._student_response = student_response;
      },

      _result: "",
      get result() {
        return !this.jsonString ? API.throwSCORMError(404) : this._result;
      },
      set result(result) {
        this._result = result;
      },

      _latency: "",
      get latency() {
        return !this.jsonString ? API.throwSCORMError(404) : this._latency;
      },
      set latency(latency) {
        this._latency = latency;
      },

      objectives: {
        childArray: [],
        get _count() {
          return this.childArray.length;
        },
        set _count(_count) {
          API.throwSCORMError(402);
        },

        toJSON: jsonFormatter,
      },

      correct_responses: {
        childArray: [],
        get _count() {
          return this.childArray.length;
        },
        set _count(_count) {
          API.throwSCORMError(402);
        },

        toJSON: jsonFormatter,
      },

      toJSON: jsonFormatter,
    };
  }

  function CMI_ObjectivesObject(API) {
    return {
      _id: "",
      get id() {
        return this._id;
      },
      set id(id) {
        this._id = id;
      },

      _status: "",
      get status() {
        return this._status;
      },
      set status(status) {
        this._status = status;
      },

      score: {
        __children: "raw,min,max",
        get _children() {
          return this.__children;
        },
        set _children(children) {
          API.throwSCORMError(402);
        },

        _raw: "",
        get raw() {
          return this._raw;
        },
        set raw(raw) {
          this._raw = raw;
        },

        _min: "",
        get min() {
          return this._min;
        },
        set min(min) {
          this._min = min;
        },

        _max: "",
        get max() {
          return this._max;
        },
        set max(max) {
          this._max = max;
        },

        toJSON: jsonFormatter,
      },

      toJSON: jsonFormatter,
    };
  }

  function CMI_InteractionsObjectivesObject(API) {
    return {
      _id: "",
      get id() {
        return !this.jsonString ? API.throwSCORMError(404) : this._id;
      },
      set id(id) {
        this._id = id;
      },

      toJSON: jsonFormatter,
    };
  }

  function CMI_InteractionsCorrectResponsesObject(API) {
    return {
      _pattern: "",
      get pattern() {
        return !this.jsonString ? API.throwSCORMError(404) : this._pattern;
      },
      set pattern(pattern) {
        this._pattern = pattern;
      },

      toJSON: jsonFormatter,
    };
  }
})();
